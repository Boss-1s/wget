package de.ullisroboterseite.ursai2popup;

import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.annotations.androidmanifest.*;
import com.google.appinventor.components.common.*;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.*;

import android.util.Log;
import android.os.Handler;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.graphics.ColorMatrixColorFilter;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.Html;
import android.view.ContextThemeWrapper;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

import java.io.*;
import java.util.*;

public class Popup implements PopupMenu.OnMenuItemClickListener {
    static final String LOG_TAG = UrsAI2Popup.LOG_TAG;

    final Form form;
    final UrsAI2Popup parent;
    PopupMenu menuPopup = null;

    int menuFontSize = 16;
    // YailList menuItemList = new YailList(); // Einträge haben die Form: <text>::<icon>::x|t|f

    int menuBackgroundColor = 0;
    int menuTextColor = 0; // Default

    boolean autoCheck = true; // Menüzeilen mit Checkbox ändern den Check-Status beim Anklicken automatisch

    static float[] mat = new float[] { //
            0.15f, 0.3f, 0.05f, 0, 120, //
            0.15f, 0.3f, 0.05f, 0, 120, //
            0.15f, 0.3f, 0.05f, 0, 120, //
            0, 0, 0, 1, 0, }; //

    static ColorMatrixColorFilter grayFilter = new ColorMatrixColorFilter(mat);

    //------------------------------------------------------
    class MenuItemDescriptor {
        String title = "";
        String icon = "";
        String checked = "x"; // x|t|f
        boolean enabled = true;

        MenuItemDescriptor(String title, String icon, String checked) {
            this.title = title;
            this.icon = icon;
            this.checked = checked;
        }

        MenuItemDescriptor(String title, String icon) {
            this.title = title;
            this.icon = icon;
        }

        MenuItemDescriptor(String title) {
            this.title = title;
        }
    }

    class MenuItemList extends ArrayList<MenuItemDescriptor> {
        static final long serialVersionUID = 1;
    }
    //------------------------------------------------------

    MenuItemList menuItemList = new MenuItemList();

    public Popup(UrsAI2Popup parent, Form form) {
        this.parent = parent;
        this.form = form;
    }

    /**
     * Zeigt das Popup-Menü an
     * @param anchor
     */
    public void show(AndroidViewComponent anchor) {
        show(anchor.getView());
    }

    /**
     * Zeigt das Popup-Menü an
     * @param anchor
     */
    public void show(View anchor) {
        if (menuItemList.size() == 0)
            return;

        if (menuPopup != null)
            dismiss();

        switch (menuBackgroundColor) {
            case 1:
                menuPopup = new PopupMenu(new ContextThemeWrapper(form, android.R.style.Theme), anchor);
                break;
            case 2:
                menuPopup = new PopupMenu(
                        new ContextThemeWrapper(form, android.R.style.Theme_DeviceDefault_NoActionBar),
                        anchor);
                break;
            default:
                menuPopup = new PopupMenu(form, anchor);
                break;
        }

        int iconCount = 0;

        for (int i = 0; i < menuItemList.size(); i++) {
            MenuItemDescriptor def = menuItemList.get(i);

            // Title, Textfarbe
            SpannableString spanString = new SpannableString(Html.fromHtml(def.title));
            spanString.setSpan(new AbsoluteSizeSpan(menuFontSize, true), 0, spanString.length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            if (menuTextColor != 0 && def.enabled)
                spanString.setSpan(new ForegroundColorSpan(menuTextColor), 0, spanString.length(),
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            // Zum Menü hinzufügen, ID ist die lfd. Nr
            MenuItem item = menuPopup.getMenu().add(0, i, 0, spanString);

            // Enabled setzen
            item.setEnabled(def.enabled);

            // Icon setzen
            if (!def.icon.isEmpty()) {
                Drawable drawable = null;
                try {
                    drawable = Drawable.createFromStream(form.openAsset(def.icon), null);
                } catch (Exception e) {
                    try {
                        drawable = Drawable.createFromStream(form.openAsset(def.icon + ".png"), null);
                    } catch (Exception e1) {
                        try {
                            drawable = Drawable.createFromStream(form.openAsset(def.icon + ".jpg"), null);
                        } catch (Exception e2) {
                            // kein erfolg
                        }
                    }
                }
                if (drawable != null) {
                    if (!def.enabled)
                        drawable.setColorFilter(grayFilter);
                    item.setIcon(drawable);
                    iconCount++;

                } // if (d != null)
            } //  if (!def.icon.isEmpty()) {

            // CheckBox setzen
            if (def.checked.equals("t")) {
                item.setCheckable(true);
                item.setChecked(true);
            } else if (def.checked.equals("f")) {
                item.setCheckable(true);
                item.setChecked(false);
            }
        } // for

        // Icons aktivieren
        if (iconCount > 0)
            Util.setForceShowIcon(menuPopup, true);

        menuPopup.setOnMenuItemClickListener(this);
        menuPopup.show();
    }

    public void dismiss() {
        if (menuPopup != null)
            menuPopup.dismiss();
        menuPopup = null;
    }

    void prepareMenuItemList(YailList itemList) {
        String[] items = itemList.toStringArray();

        menuItemList = new MenuItemList();

        for (int i = 0; i < items.length; i++) {
            MenuItemDescriptor def = null;
            String itemString = items[i];
            String[] itemParams = itemString.split("::");

            if (itemParams.length == 0) {
                continue; // keine leeren Zeilen
            }
            itemParams[0] = itemParams[0].trim();
            if (itemParams.length == 1) {
                def = new MenuItemDescriptor(itemParams[0]);
            } else if (itemParams.length == 2) {
                def = new MenuItemDescriptor(itemParams[0], itemParams[1].trim());
            } else { // >2
                if (itemParams[2].toLowerCase().startsWith("t")) // Checked: true
                    def = new MenuItemDescriptor(itemParams[0], itemParams[1].trim(), "t");
                else if (itemParams[2].toLowerCase().startsWith("f")) // Checked: false
                    def = new MenuItemDescriptor(itemParams[0], itemParams[1].trim(), "f");
                else // irgendetwas ungültiges
                    def = new MenuItemDescriptor(itemParams[0], itemParams[1].trim());
            }
            menuItemList.add(def);
        } // for
    } // prepareMenuItemList

    // ====================================================
    // MenuItemClick Handler
    // ====================================================

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        int id = menuItem.getItemId();
        String title = menuItem.getTitle().toString();
        MenuItemDescriptor def = menuItemList.get(id);

        boolean checkAble = !def.checked.equals("x");
        boolean checked = def.checked.equals("t");

        if (autoCheck && checkAble) {
            checked = !checked;
            setItemChecked(id + 1, checked);
        }

        parent.MenuItemSelected(id + 1, title, checked);
        switch (id) {
            case 0:
                parent.MenuItem1Selected(title, checked);
                break;
            case 1:
                parent.MenuItem2Selected(title, checked);
                break;
            case 2:
                parent.MenuItem3Selected(title, checked);
                break;
            case 3:
                parent.MenuItem4Selected(title, checked);
                break;
            case 4:
                parent.MenuItem5Selected(title, checked);
                break;
            default:
                break;
        }

        return true;
    }

    // ====================================================
    // Menü
    // ====================================================

    /**
     * Legt die Menüeinträge fest.
     * @param menuItemList Liste der Menüeinträge
     */
    public void setMenuItems(final YailList menuItemList) {
        prepareMenuItemList(menuItemList);
    }

    /**
     * Liest die Menüeinträge aus einem Asset.
     * @param FileName Der Dateiname des Assets.
     * @note Bei Fehlern wird keine Item-Liste erstellt.
     */
    public void loadMenuItemsFromFile(String FileName) {
        try {
            String line;
            List<String> lines = new ArrayList<String>();
            InputStream in = form.openAsset(FileName);
            InputStreamReader ir = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(ir);
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty())
                    lines.add(line);
            }
            prepareMenuItemList(YailList.makeList(lines));
        } catch (Exception e) {
            // nichts tun
        }
    }

    /**
     * Legt die Schriftgröße der Menüenträge fest.
     * @param size Die zu verwendende Schriftgröße für Menüeinträge.
     */
    public void setMenuFontSize(int size) {
        menuFontSize = size;
    }

    /**
     * Ruft die aktuelle Schriftgröße der Menüenträge ab.
     * @return Die aktuelle Schriftgröße für Menüeinträge.
     */
    public int getMenuFontSize() {
        return menuFontSize;
    }

    /**
    * Legt die Hintergrundfarbe des Popup-Menüs fest
    * @param color 0: default, 1: weiß, 2: schwarz
    */
    public void setMenuBackgroundColor(int color) {
        menuBackgroundColor = color;
    }

    /**
     * Legt die Textfarbe des Menüsfest.
     * @param argb Die zu verwendende Textfarbe.
     */
    public void setMenuTextColor(int argb) {
        menuTextColor = argb;
    }

    /**
     * Ruft die aktuelle Textfarbe des Menüs ab.
     * @return Die aktuelle Textfarbe.
     */
    public int getMenuTextColor() {
        return menuTextColor;
    }

    /**
     * Legt fest, ob sich der Check-Status Menüzeilen mit CheckBox automatisch ändert.
     * @param value
     */
    public void setAutoCheck(boolean value) {
        autoCheck = value;
    }

    /**
     * Setzt die Ckeck-Option für ein Item
     * @param itemNo Lfd. Menüzeilennummer beginnend bei 1
     * @param value
     */
    public void setItemChecked(int itemNo, boolean value) {
        if (itemNo < 1 || itemNo > menuItemList.size())
            return;

        menuItemList.get(itemNo - 1).checked = value ? "t" : "f";
    }

    /**
     * Setzt die Enabled-Option für ein Item
     * @param itemNo Lfd. Menüzeilennummer beginnend bei 1
     * @param value
     */
    public void setMenuItemEnabled(int itemNo, boolean value) {
        if (itemNo < 1 || itemNo > menuItemList.size())
            return;

        menuItemList.get(itemNo - 1).enabled = value;
    }

}