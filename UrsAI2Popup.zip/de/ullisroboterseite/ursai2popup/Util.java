package de.ullisroboterseite.ursai2popup;

import java.io.StringWriter;
import java.io.PrintWriter;
import java.lang.reflect.*;

import android.widget.PopupMenu;
import android.os.Build;
import android.util.Log;

/**
 * Statische Hilfsfunktionen
 */
public class Util {
   static final String LOG_TAG = UrsAI2Popup.LOG_TAG;

   /**
    * Liefert den StackTrace der Exception als String.
    * @param e Die Exception, zu der der StackTrace zurück geliefert werden soll.
    * @return Der ermittelte StackTrace
    */
   static String getStackTrace(Throwable e) {
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      e.printStackTrace(pw);
      String stackTrace = sw.toString(); // stack trace as a string
      return stackTrace;
   }

   /**
    * Legt fest, ob im Popup-Menü Symbole angezeigt werden soll.
    * @param popupMenu Das Menü, zu dem Symbole angezeigt werden sollen
    * @param forceShowIcon true oder false
    * @note Ab API Lvel 29 gibt es hierzu eine Funktion.
    *       In einigen älteren Version funktioniert ein Reflection-Hack
    */
   static void setForceShowIcon(PopupMenu popupMenu, boolean forceShowIcon) {
      if (Build.VERSION.SDK_INT >= 29) {
         popupMenu.setForceShowIcon(forceShowIcon);
      } else {
         try {
            Field[] fields = popupMenu.getClass().getDeclaredFields();
            for (Field field : fields) {
               if ("mPopup".equals(field.getName())) {
                  field.setAccessible(true);
                  Object menuPopupHelper = field.get(popupMenu);
                  Class<?> classPopupHelper = Class.forName(menuPopupHelper.getClass().getName());
                  Method setForceIcons = classPopupHelper.getMethod("setForceShowIcon", boolean.class);
                  setForceIcons.invoke(menuPopupHelper, forceShowIcon);
                  break;
               }
            }
         } catch (Exception ex) {
            // nichts tun
         }
      }
   }
 }