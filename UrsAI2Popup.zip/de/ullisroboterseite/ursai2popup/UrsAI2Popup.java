package de.ullisroboterseite.ursai2popup;

// Autor: https://UllisRoboterSeite.de

// Doku:  https://UllisRoboterSeite.de/android-AI2-Popup.html
//
// Version 1.0 (2021-01-20)
// -------------------------
// - Basis-Version
//
// Version 1.1 (2022-09-21)
// -------------------------
// - Methode Dismiss hinzugefügt.

//TODO: FontSize & MenuFontSize sollten float sein

import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.annotations.androidmanifest.*;
import com.google.appinventor.components.common.*;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.*;

import android.util.Log;
import android.os.Handler;
import android.content.Context;

@DesignerComponent(version = 1, //
        versionName = UrsAI2Popup.VersionName, //
        dateBuilt = "2022-09-21", //
        description = "AI2 extension Popup menu component.", //
        category = com.google.appinventor.components.common.ComponentCategory.EXTENSION, //
        nonVisible = true, //
        helpUrl = "https://UllisRoboterSeite.de/android-AI2-Popup.html", //
        androidMinSdk = 11, //
        iconName = "aiwebres/icon.png")
@SimpleObject(external = true)
public class UrsAI2Popup extends AndroidNonvisibleComponent {
    static final String LOG_TAG = "POP";
    static final String VersionName = "1.1.0";

    final Context context;
    Handler handler = new Handler();

    final Popup popup;

    AndroidViewComponent anchor = null;

    public UrsAI2Popup(ComponentContainer container) {
        super(container.$form());
        context = container.$context();

        popup = new Popup(this, container.$form());
    }

    @SimpleProperty(description = "Returns the component's version name.")
    public String Version() {
        return VersionName;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_COMPONENT, defaultValue = "")
    @SimpleProperty(description = "Anchor for the Popup menu")
    public void Anchor(AndroidViewComponent viewComponent) {
        anchor = viewComponent;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN, defaultValue ="True")
    @SimpleProperty(description = "Specifies wether checkable menu item change there check state automaticly.", userVisible=false)
    public void AutoCheck(boolean value) {
        popup.setAutoCheck(value);
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_TEXTAREA, defaultValue = "")
    @SimpleProperty(description = "Set the list of choices from a string of comma-separated values.")
    public void MenuItemsFromString(String itemstring) {
        popup.setMenuItems(ElementsUtil.elementsFromString(itemstring));
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_NON_NEGATIVE_INTEGER, defaultValue = "16")
    @SimpleProperty(description = "Specifies the menu's font size, measured in sp(scale-independent pixels).")
    public void MenuFontSize(int size) {
        popup.setMenuFontSize(size);
    }

    @SimpleProperty(description = "Gets the menu's font size.")
    public int MenuFontSize() {
        return popup.getMenuFontSize();
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_CHOICES, defaultValue = "Default", //
            editorArgs = { "Default", "White", "Black" })
    @SimpleProperty(description = "Sets the menu's backgroun color.")
    public void MenuBackgroundColor(String value) {
        switch (value.toLowerCase()) {
            case "white":
                popup.setMenuBackgroundColor(1);
                break;
            case "black":
                popup.setMenuBackgroundColor(2);
                break;
            default:
                popup.setMenuBackgroundColor(0);
                break;
        }
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_COLOR, defaultValue = Component.DEFAULT_VALUE_COLOR_WHITE)
    @SimpleProperty(description = "Specifies the menu's text color as an alpha-red-green-blue integer.")
    public void MenuTextColor(int argb) {
        popup.setMenuTextColor(argb);
    }

    @SimpleProperty(description = "Returns the menu's text color as an alpha-red-green-blue integer.")
    @IsColor
    public int MenuTextColor() {
        return popup.getMenuTextColor();
    }

    // =============================================================
    // Funktionen
    // =============================================================

    @SimpleFunction(description = "Loads the menu items form a list.")
    public void SetMenuItems(YailList ItemList) {
        popup.setMenuItems(ItemList);
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_ASSET, defaultValue = "")
    @SimpleProperty(description = "Loads the menu items from a file.", userVisible = false)
    public void MenuItemsFromFile(String FileName) {
        popup.loadMenuItemsFromFile(FileName);
    }

    @SimpleFunction(description = "Loads the menu items from a file.", userVisible = false)
    public void LoadMenuItemsFromFile(String FileName) {
        popup.loadMenuItemsFromFile(FileName);
    }

    @SimpleFunction(description = "Opens the menu.")
    public void Show() {
        popup.show(anchor);
    }

    @SimpleFunction(description = "Closes the menu.")
    public void Dismiss() {
        popup.dismiss();
    }


    @SimpleFunction(description = "Sets the check state of a menu item.")
    public void SetMenuItemChecked(int ItemNo, boolean Value) {
        popup.setItemChecked(ItemNo, Value);
    }

    @SimpleFunction(description = "Sets enabled state of a menu item.")
    public void SetMenuItemEnabled(int ItemNo, boolean Value) {
        popup.setMenuItemEnabled(ItemNo, Value);
    }

    // =============================================================
    // Events
    // =============================================================

    @SimpleEvent(description = "Menu item was selected")
    public void MenuItemSelected(int ID, String Title, boolean Checked) {
        EventDispatcher.dispatchEvent(this, "MenuItemSelected", ID, Title, Checked);
    }

    @SimpleEvent(description = "Menu item #1 was selected")
    public void MenuItem1Selected(String Title, boolean Checked) {
        EventDispatcher.dispatchEvent(this, "MenuItem1Selected", Title, Checked);
    }

    @SimpleEvent(description = "Menu item #2 was selected")
    public void MenuItem2Selected(String Title, boolean Checked) {
        EventDispatcher.dispatchEvent(this, "MenuItem2Selected", Title, Checked);
    }

    @SimpleEvent(description = "Menu item #3 was selected")
    public void MenuItem3Selected(String Title, boolean Checked) {
        EventDispatcher.dispatchEvent(this, "MenuItem3Selected", Title, Checked);
    }

    @SimpleEvent(description = "Menu item #4 was selected")
    public void MenuItem4Selected(String Title, boolean Checked) {
        EventDispatcher.dispatchEvent(this, "MenuItem4Selected", Title, Checked);
    }

    @SimpleEvent(description = "Menu item #5 was selected")
    public void MenuItem5Selected(String Title, boolean Checked) {
        EventDispatcher.dispatchEvent(this, "MenuItem5Selected", Title, Checked);
    }
}
