#!/data/data/com.termux/files/usr/bin/bash
# Verity STT bridge — Android / Termux
# Do NOT use the openai SDK (jiter/maturin/Rust fails on Termux).
# Groq is called via httpx (groq_http.py).
set -e
cd "$(dirname "$0")"

echo "=== Verity Android STT bridge (Termux) ==="
echo

if command -v sed >/dev/null 2>&1; then
  sed -i 's/\r$//' "$0" 2>/dev/null || true
fi

if ! command -v python >/dev/null 2>&1; then
  echo "Python missing. Run: pkg install python"
  exit 1
fi

if [ ! -f .env ]; then
  echo "Missing .env (hidden file — check with: ls -la)"
  echo "  Extract with Termux unzip to keep .env:"
  echo "  cd /storage/emulated/0/Download && unzip -o verity-android-setup.zip"
  echo "  (or: /sdcard/Download    or    ~/storage/downloads)"
  echo "  cp -a verity-android-setup/.env ~/verity-android-setup/.env"
  exit 1
fi

echo "OK: .env present ($(wc -c < .env) bytes)"
python -V
echo

if [ ! -f groq_http.py ]; then
  echo "Missing groq_http.py — unzip verity-android-setup.zip again (keep groq_http.py)"
  exit 1
fi

export VERITY_MIC_BACKEND="${VERITY_MIC_BACKEND:-termux}"

echo "[1/3] Installing light packages (NO openai — avoids jiter/maturin)..."
# Do NOT: pip install --upgrade pip
# Do NOT: pip install openai
pip install python-dotenv httpx --break-system-packages

echo "[2/3] Websockets..."
# 10.4 is what old Termux/Python used. Fresh Termux (Python 3.13/3.14) often
# cannot install it, then players end up on latest websockets which is strict
# about Minecraft Bedrock close codes. mc_bridge patches that either way.
if pip install "websockets==10.4" --break-system-packages; then
  echo "websockets 10.4 OK"
else
  echo "websockets 10.4 not available — installing a current build"
  pip install "websockets>=12,<16" --break-system-packages
fi
python -c "import websockets; print('using websockets', websockets.__version__)"

echo
echo "[3/3] Starting bridge — you should see: Listening on 127.0.0.1:3000"
echo "  Minecraft: /connect 127.0.0.1:3000"
echo

if command -v pkill >/dev/null 2>&1; then
  pkill -f "mc_bridge.py" 2>/dev/null || true
  sleep 0.4
fi

python -u mc_bridge.py
