#!/data/data/com.termux/files/usr/bin/bash
# Reinstall helpers — no openai SDK
set -e
cd "$HOME/verity-android-setup" || {
  echo "Copy the folder first: cp -a .../verity-android-setup/. ~/verity-android-setup/"
  exit 1
}

pkg update -y
pkg install -y python openssl libffi termux-api dos2unix

dos2unix start_android.sh 2>/dev/null || sed -i 's/\r$//' start_android.sh
chmod +x start_android.sh

# Remove openai/jiter if previously installed (avoids conflicts)
pip uninstall -y openai jiter maturin 2>/dev/null || true

pip install python-dotenv httpx websockets==10.4 --break-system-packages

echo "=== Starting bridge ==="
bash start_android.sh
