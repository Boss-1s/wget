"""
Mic backend picker: Termux on Android, sounddevice on Windows.
"""

from __future__ import annotations

import os
import sys


def _want_termux() -> bool:
    forced = os.getenv("VERITY_MIC_BACKEND", "").strip().lower()
    if forced in ("termux", "android"):
        return True
    if forced in ("windows", "sounddevice", "pc"):
        return False
    # Auto-detect Termux
    return (
        "com.termux" in (os.environ.get("PREFIX") or "")
        or os.path.exists("/data/data/com.termux")
        or "ANDROID_ROOT" in os.environ
    )


if _want_termux():
    from android_mic import (  # noqa: F401
        list_input_devices,
        mic_backend_name,
        record_microphone_wav,
    )
else:
    from windows_mic import (  # noqa: F401
        list_input_devices,
        mic_backend_name,
        record_microphone_wav,
    )
