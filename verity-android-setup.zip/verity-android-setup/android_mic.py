"""
Termux microphone for Verity STT — stays in Minecraft (no app switch).

Uses:
  termux-microphone-record -f out.m4a -e aac -l 0
  termux-microphone-record -q

Shows a short recording notification, then ALWAYS removes it when done.
Requires Termux:API Microphone = Allow (prefer "all the time" if offered).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
from typing import Optional

RECORD_SECONDS = 5
# Numeric string IDs are most reliable with termux-notification-remove.
NOTIF_ID = "8121"


def _which(cmd: str) -> str | None:
    return shutil.which(cmd)


def termux_available() -> bool:
    return _which("termux-microphone-record") is not None


def _run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, check=False, capture_output=True, text=True)


def _run_mic(args: list[str]) -> subprocess.CompletedProcess[str]:
    return _run(["termux-microphone-record", *args])


def _toast(msg: str) -> None:
    if _which("termux-toast"):
        _run(["termux-toast", "-s", "-g", "middle", msg])


def _notif_start(seconds: int) -> None:
    if not _which("termux-notification"):
        return
    # No --ongoing: if remove ever fails, user can still swipe it away.
    # Priority default is enough for a 5s mic cue.
    result = _run(
        [
            "termux-notification",
            "--id",
            NOTIF_ID,
            "--title",
            "Verity mic",
            "--content",
            f"Recording {seconds}s — speak in Minecraft",
            "--priority",
            "high",
        ]
    )
    if result.returncode != 0:
        err = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
        print(f"[mic] notif start warn: {err or result.returncode}", flush=True)


def _notif_stop() -> None:
    """
    termux-notification-remove takes a positional id:
      termux-notification-remove 8121
    NOT: termux-notification-remove --id 8121  (that silently fails → stuck notif)
    """
    removed = False
    if _which("termux-notification-remove"):
        # Try known ids (current + old string id from earlier builds).
        for nid in (NOTIF_ID, "verity-mic", "8121"):
            result = _run(["termux-notification-remove", nid])
            if result.returncode == 0:
                removed = True
            else:
                # Some builds accept --id; try both.
                _run(["termux-notification-remove", "--id", nid])

    if not removed and _which("termux-notification"):
        # Overwrite same id with a dismissible "done" flash, then remove again.
        _run(
            [
                "termux-notification",
                "--id",
                NOTIF_ID,
                "--title",
                "Verity mic",
                "--content",
                "Done",
                "--priority",
                "low",
            ]
        )
        time.sleep(0.15)
        if _which("termux-notification-remove"):
            _run(["termux-notification-remove", NOTIF_ID])

    print("[mic] notification cleared", flush=True)


def _wake_unlock() -> None:
    if _which("termux-wake-unlock"):
        _run(["termux-wake-unlock"])


def _home_record_dir() -> str:
    candidates = [
        os.path.join(os.path.expanduser("~"), "verity-mic"),
        "/storage/emulated/0/Download/verity-mic",
        "/sdcard/Download/verity-mic",
        tempfile.gettempdir(),
    ]
    for folder in candidates:
        try:
            os.makedirs(folder, exist_ok=True)
            probe = os.path.join(folder, ".write_test")
            with open(probe, "w", encoding="utf-8") as f:
                f.write("ok")
            os.remove(probe)
            return folder
        except OSError:
            continue
    return tempfile.gettempdir()


def _wait_for_file(path: str, min_bytes: int, timeout: float) -> int:
    deadline = time.monotonic() + timeout
    last = -1
    stable = 0
    while time.monotonic() < deadline:
        if os.path.exists(path):
            size = os.path.getsize(path)
            if size >= min_bytes:
                if size == last:
                    stable += 1
                    if stable >= 3:
                        return size
                else:
                    stable = 0
                    last = size
        time.sleep(0.2)
    return os.path.getsize(path) if os.path.exists(path) else 0


def record_microphone_wav(
    path: Optional[str] = None,
    seconds: float = RECORD_SECONDS,
) -> str:
    if not termux_available():
        raise RuntimeError(
            "termux-microphone-record not found.\n"
            "  pkg install termux-api\n"
            "  Install Termux:API app + Microphone permission"
        )

    limit = max(1, int(round(seconds)))

    if path is None:
        out = os.path.join(
            _home_record_dir(),
            f"verity_{int(time.time())}_{os.getpid()}.m4a",
        )
    else:
        root, ext = os.path.splitext(path)
        out = path if ext.lower() == ".m4a" else root + ".m4a"

    if os.path.exists(out):
        try:
            os.remove(out)
        except OSError as exc:
            raise RuntimeError(f"Cannot replace {out}: {exc}") from exc

    _run_mic(["-q"])
    time.sleep(0.2)

    if _which("termux-wake-lock"):
        _run(["termux-wake-lock"])

    _notif_start(limit)
    _toast(f"Speak now — {limit}s")

    print(
        f"[mic] Recording {limit}s AAC (stay in Minecraft) → {out}",
        flush=True,
    )

    try:
        start = _run_mic(["-f", out, "-e", "aac", "-l", "0"])
        combined = ((start.stdout or "") + "\n" + (start.stderr or "")).strip()
        print(f"[mic] start: {combined or '(silent)'}", flush=True)

        lower = combined.lower()
        if "permission" in lower or "denied" in lower:
            raise RuntimeError(
                "Mic permission denied.\n"
                "Settings → Termux:API → Microphone → Allow / Cho phep moi luc"
            )

        if "already in progress" in lower or "already exists" in lower:
            _run_mic(["-q"])
            time.sleep(0.3)
            if os.path.exists(out):
                os.remove(out)
            start = _run_mic(["-f", out, "-e", "aac", "-l", "0"])
            combined = ((start.stdout or "") + "\n" + (start.stderr or "")).strip()
            print(f"[mic] retry: {combined or '(silent)'}", flush=True)

        info = _run_mic(["-i"])
        info_txt = ((info.stdout or "") + "\n" + (info.stderr or "")).strip()
        if info_txt:
            print(f"[mic] info: {info_txt}", flush=True)

        time.sleep(float(limit))
        _run_mic(["-q"])
        time.sleep(0.7)

        size = _wait_for_file(out, min_bytes=800, timeout=5.0)
        if size < 800:
            raise RuntimeError(
                "Termux mic empty (no app switch).\n"
                f"  file={out} size={size}\n"
                "Mic dang de 'Chi khi dang dung app' → Android chan mic khi MC mo.\n"
                "Thu:\n"
                "  1) Termux:API → Mic → 'Cho phep moi luc' (neu co)\n"
                "  2) Battery Unrestricted cho Termux + Termux:API\n"
                "  3) Acquire wakelock trong thong bao Termux\n"
                "  4) Test ngoai MC:\n"
                "       termux-microphone-record -f ~/test.m4a -e aac -l 0\n"
                "       (noi 3s) termux-microphone-record -q && ls -la ~/test.m4a\n"
                "Neu van empty khi MC mo: may nay khong cho mic nen — dung !verity <chu>."
            )

        print(f"[mic] Done ({size} bytes) → {out}", flush=True)
        return out
    finally:
        try:
            _run_mic(["-q"])
        except Exception:
            pass
        _notif_stop()
        _wake_unlock()


def mic_backend_name() -> str:
    return "termux" if termux_available() else "termux-missing"


def list_input_devices() -> list[str]:
    if termux_available():
        return ["  [termux] Phone mic AAC (stay in Minecraft, no jump)"]
    return ["  [!] termux-microphone-record not found"]
