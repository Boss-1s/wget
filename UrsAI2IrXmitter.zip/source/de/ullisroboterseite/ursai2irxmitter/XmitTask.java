package de.ullisroboterseite.ursai2irxmitter;

import android.hardware.ConsumerIrManager;
import android.hardware.ConsumerIrManager.*;

public class XmitTask extends UrsAsyncTask {
    ITaskStoppedListener caller;
    int carrierFrequency;
    int[] startPattern;
    int[] followingPattern;
    int numberOfRepetitions;
    int startDelay;
    int repDelay;

    XmitTask(ITaskStoppedListener caller, //
            int carrierFrequency, int[] startPattern, int[] followingPattern, int numberOfRepetitions, int startDelay,
            int repDelay) {
        this.caller = caller;
        this.carrierFrequency = carrierFrequency;
        this.startPattern = startPattern;
        this.followingPattern = followingPattern;
        this.numberOfRepetitions = numberOfRepetitions;
        this.startDelay = startDelay;
        this.repDelay = repDelay;
    }

    // startet den Thread
    void start() {
        doStart();
    }

    public void doInBackground() {
        final ConsumerIrManager irManager = caller.getIrManager();
        irManager.transmit(carrierFrequency, startPattern);
        caller.onXmitRepeat();
        if (keepRunning()) {
            sleep(startDelay);
            if (numberOfRepetitions < 0) {
                while (keepRunning()) {
                    irManager.transmit(carrierFrequency, followingPattern);
                    caller.onXmitRepeat();
                    if (!keepRunning())
                        break;
                    sleep(repDelay);
                }
            } else {
                for (int i = 0; i < numberOfRepetitions; i++) {
                    if (!keepRunning())
                        break;
                    irManager.transmit(carrierFrequency, followingPattern);
                    caller.onXmitRepeat();
                    if (!keepRunning())
                        break;
                    sleep(repDelay);
                }
            }
        }
        caller.onTaskStopped();
    }
}