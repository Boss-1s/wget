package de.ullisroboterseite.ursai2irxmitter;

// Autor: https://UllisRoboterSeite.de

// Doku:  https://UllisRoboterSeite.de/android-AI2-IRXmitter.html
// Created: 2020-05-11
//
// Version 1.0 (2020-05-11)
// -------------------------
// - Basis-Version
//

import java.util.*;

import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.common.*;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.YailList;

import android.content.Context;
import android.app.Activity;
import android.os.Handler;
import android.view.*;
import android.util.Log;

import android.hardware.ConsumerIrManager;
import android.hardware.ConsumerIrManager.*;

@DesignerComponent(version = 1, //
        versionName = "1.0", //
        dateBuilt = "2020-05-15", //
        description = "AI2 extension block for IR control.", //
        category = com.google.appinventor.components.common.ComponentCategory.EXTENSION, //
        nonVisible = true, //
        helpUrl = "https://UllisRoboterSeite.de/android-AI2-IRXmitter.html", //
        iconName = "aiwebres/icon.png")
@UsesPermissions(permissionNames = "android.permission.TRANSMIT_IR")
@SimpleObject(external = true)
public class UrsAI2IrXmitter extends AndroidNonvisibleComponent
        implements Component, ITaskStoppedListener, View.OnTouchListener {
    final Context thisContext;
    final Activity thisActivity;

    final Handler handler = new Handler();
    final UrsAI2IrXmitter thisInstance = this;

    final ConsumerIrManager irManager;

    final boolean hasTransmitter; // true, wenn das Gerät einen IR-Transmitter besitzt.
    final YailList carrierFrequenciesList; // Liste der unterstützen Übertragungsfrequenzen
    final int[] carrierFrequencies; // Liste der unterstützen Übertragungsfrequenzen
    String carrierFrequenciesListString = ""; // Komma-separierte Liste der unterstützen Frequencen.

    int carrierFrequency = 38000; // Aktuell eingestellte Übertragungsfrequenz. Standardfrequenz ist 38 kHz.
    int startDelay = 500; // Verzögerung vor der 1. Wiederholung
    int repDelay = 300; // Verzögerung zwischen den Wiederholungen.

    int doneDelay = 0; // Verzögerung vor Auslösen vom TransmitDone bei Einzel-Übertragung (max. 1000)

    XmitTask xmitTask = null;

    // ----- Fehlercodes ------------
    // com.google.appinventor.components.runtime.util.ErrorMessages definiert Codes
    // bis zum Wert Error 4004
    // Diese Extension nutzt Werte von 17300 aufwärts.

    public static final int HAS_NO_IR_TRANSMITTER = 17301;
    public static final String INVALID_CARRIER_FREQENCY_Msg = "Carrier frequency is not supported.";
    public static final int INVALID_CARRIER_FREQENCY = 17302;
    public static final String HAS_NO_IR_TRANSMITTER_Msg = "Device does not have an IR transmitter.";
    public static final int INVALID_PATTERN = 17303;
    public static final String INVALID_PATTERN_Msg = "Cannot convert pattern to integers";
    public static final int INVALID_REPEAT_PATTERN = 17304;

    public static final int TRANSMITTING_IS_ACTIVE = 17305;
    public static final String TRANSMITTING_IS_ACTIVE_Msg = "Nested transmits are not allowed";

    public static final int NOT_BUTTON = 17306;
    public static final String NOT_BUTTON_Msg = "Component is not a Button.";
    public static final int INVALID_EVENT_DELAY = 17307;
    public static final String INVALID_EVENT_DELAY_Msg = "Invalid value for EventTransmitDoneDelay.";
    public static final int INVALID_START_DELAY = 17308;
    public static final String INVALID_START_DELAY_Msg = "Invalid value for StartDelay.";
    public static final int INVALID_REP_DELAY = 17309;
    public static final String INVALID_REP_DELAY_Msg = "Invalid value for RepetitionDelay.";

    static final String LOG_TAG = "IR";

    public UrsAI2IrXmitter(ComponentContainer container) {
        super(container.$form());
        thisContext = container.$context();
        thisActivity = (Activity) thisContext;

        irManager = (ConsumerIrManager) thisContext.getSystemService(Context.CONSUMER_IR_SERVICE);

        // - Unterstütze Sendefrequenzen ermitteln
        ArrayList<Integer> cf = new ArrayList<>();

        if (irManager != null) {
            if (irManager.hasIrEmitter()) {
                hasTransmitter = true;
                CarrierFrequencyRange[] cfr = irManager.getCarrierFrequencies();

                for (int i = 0; i < cfr.length; i++) {
                    carrierFrequenciesListString += ", " + cfr[i].getMinFrequency();
                    cf.add(cfr[i].getMinFrequency());
                }
            } else {
                hasTransmitter = false;
            }
        } else {
            hasTransmitter = false;
        }
        if (!carrierFrequenciesListString.isEmpty())
            carrierFrequenciesListString = carrierFrequenciesListString.substring(2);
        carrierFrequenciesList = YailList.makeList(cf);

        carrierFrequencies = new int[cf.size()];
        for (int i = 0; i < cf.size(); i++)
            carrierFrequencies[i] = cf.get(i).intValue();
    } // ctor

    @Override
    public ConsumerIrManager getIrManager() {
        return irManager;
    }

    @SimpleProperty(description = "Returns the wether an IR transmitter is supportet.")
    public boolean HasIrEmitter() {
        return hasTransmitter;
    }

    @SimpleProperty(description = "Returns the supported IR carrier frequencies as comma separated list.")
    public String CarrierFrequencies() {
        return carrierFrequenciesListString;
    }

    @SimpleProperty(description = "Return the list of supported IR carrier frequencies.")
    public YailList CarrierFrequencyList() {
        return carrierFrequenciesList;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_INTEGER, defaultValue = "500")
    @SimpleProperty(description = "Delay before the first repetition (0...1000).")
    public void StartDelay(int value) {
        final String functionName = "StartDelay";
        if (value < 0 || value > 1000) {
            form.ErrorOccurred(this, functionName, INVALID_START_DELAY, INVALID_START_DELAY_Msg);
            return;
        }
        startDelay = value;
    }

    @SimpleProperty(description = "Delay before the first repetition.")
    public int StartDelay() {
        return startDelay;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_INTEGER, defaultValue = "300")
    @SimpleProperty(description = "Delay before the first repetition.")
    public void RepetitionDelay(int value) {
        final String functionName = "RepetitionDelay";
        if (value < 0 || value > 1000) {
            form.ErrorOccurred(this, functionName, INVALID_REP_DELAY, INVALID_REP_DELAY_Msg);
            return;
        }
        repDelay = value;
    }

    @SimpleProperty(description = "Delay before the first repetition.")
    public int RepetitionDelay() {
        return repDelay;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_INTEGER, defaultValue = "0")
    @SimpleProperty(description = "Delay before raising event TransmitDone at single shots.")
    public void EventTransmitDoneDelay(int value) {
        final String functionName = "EventTransmitDoneDelay";
        if (value < 0 || value > 1000) {
            form.ErrorOccurred(this, functionName, INVALID_EVENT_DELAY, INVALID_EVENT_DELAY_Msg);
            return;
        }
        doneDelay = value;
    }

    @SimpleProperty(description = "Delay before raising event TransmitDone at single shots.")
    public int EventTransmitDoneDelay() {
        return doneDelay;
    }

    void sleep(int dur) {
        try {
            Thread.sleep(dur);
        } catch (Exception e) {
            // nichts zu tun
        }
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_INTEGER, defaultValue = "38000")
    @SimpleProperty(description = "The IR carrier frequency in Hertz.")
    public void CarrierFrequency(int value) {
        final String functionName = "CarrierFrequency";
        if (hasTransmitter) {
            for (int i = 0; i < carrierFrequencies.length; i++) {
                if (value == carrierFrequencies[i]) {
                    carrierFrequency = value;
                    return;
                }
            }
            form.ErrorOccurred(this, functionName, INVALID_CARRIER_FREQENCY, INVALID_CARRIER_FREQENCY_Msg);
        }
        form.ErrorOccurred(this, functionName, HAS_NO_IR_TRANSMITTER, HAS_NO_IR_TRANSMITTER_Msg);
    }

    @SimpleProperty(description = "The IR carrier frequency in Hertz.")
    public int CarrierFrequency() {
        return carrierFrequency;
    }

    @SimpleProperty(description = "True if an asynchron transfer is active.")
    public boolean IsTransmitting() {
        return xmitTask != null;
    }

    // ToDo: auch über den Thread auslösen mit Repetition = 0.
    @SimpleFunction(description = "Transmits an infrared pattern.\nThis method is synchronous; "
            + "when it returns the pattern has been transmitted. Only patterns shorter than 2 seconds will be transmitted.")
    public void Transmit(String Pattern) {
        final String functionName = "Transmit";
        if (!hasTransmitter) {
            form.ErrorOccurred(this, functionName, HAS_NO_IR_TRANSMITTER, HAS_NO_IR_TRANSMITTER_Msg);
            return;
        }

        if (xmitTask != null) {
            form.ErrorOccurred(this, functionName, TRANSMITTING_IS_ACTIVE, TRANSMITTING_IS_ACTIVE_Msg);
            return;
        }
        int[] pattern = patternToIntegerArray(Pattern);

        if (pattern == null) {
            form.ErrorOccurred(this, functionName, INVALID_PATTERN, INVALID_PATTERN_Msg);
            return;
        }

        irManager.transmit(carrierFrequency, pattern);
        PatternXmitted();
        TransmitDoneDelayed();
    }

    @SimpleFunction(description = "Transmits repeated infrared pattern asyncronously. "
            + "Infinite repetitions when NumberOfRepetitions < 0." + "\nThis method returns immediately.")
    public void RepeatedTransmit(int Repetitions, String Pattern) {
        final String functionName = "RepeatedTransmit";
        startTransmitTask(functionName, Repetitions, Pattern, Pattern);
    }

    @SimpleFunction(description = "Transmits repeated infrared pattern asyncronously. "
            + "Infinite repetitions when NumberOfRepetitions < 0." + "\nThis method returns immediately.")
    public void RepeatedAlternateTransmit(int Repetitions, String Pattern, String AltPattern) {
        final String functionName = "RepeatedAlternateTransmit";
        startTransmitTask(functionName, Repetitions, Pattern, AltPattern);
    }

    void startTransmitTask(String functionName, int Repetitions, String Pattern, String AltPattern) {
        if (!hasTransmitter) {
            form.ErrorOccurred(this, functionName, HAS_NO_IR_TRANSMITTER, HAS_NO_IR_TRANSMITTER_Msg);
            return;
        }

        if (xmitTask != null) {
            form.ErrorOccurred(this, functionName, TRANSMITTING_IS_ACTIVE, TRANSMITTING_IS_ACTIVE_Msg);
            return;
        }

        int[] pattern = patternToIntegerArray(Pattern);
        if (pattern == null) {
            form.ErrorOccurred(this, functionName, INVALID_PATTERN, INVALID_PATTERN_Msg);
            return;
        }

        int[] secondPattern = patternToIntegerArray(AltPattern);
        if (secondPattern == null) {
            form.ErrorOccurred(this, functionName, INVALID_REPEAT_PATTERN, INVALID_PATTERN_Msg);
            return;
        }

        xmitTask = new XmitTask(this, carrierFrequency, pattern, secondPattern, Repetitions, startDelay, repDelay);
        xmitTask.start();
    }

    @SimpleFunction(description = "Stops an active transmission.")
    public void StopTransmission() {
        if (xmitTask != null)
            xmitTask.stop();
    }

    @SimpleEvent(description = "The transmission has ended.")
    public void TransmitDone() {
        Log.d(LOG_TAG, "Transmit Done");
        handler.post(new Runnable() {
            public void run() {
                EventDispatcher.dispatchEvent(thisInstance, "TransmitDone");
            } // run
        }); // post
    }

    // Übertragung beendet
    @Override
    public void onTaskStopped() {
        xmitTask = null;
        TransmitDone();
    }

    public void TransmitDoneDelayed() {
        if (doneDelay > 0) {
            Log.d(LOG_TAG, "Transmit DoneDelayed");
            handler.postDelayed(new Runnable() {
                public void run() {
                    EventDispatcher.dispatchEvent(thisInstance, "TransmitDone");
                } // run
            }, doneDelay); // post
        } else
            TransmitDone();
    }

    @SimpleEvent(description = "Pattern has beeb transmittet.\n"
            + "The event is triggered asynchronously immediately after the transmission and before the delay to the next transmission.\n")
    public void PatternXmitted() {
        Log.d(LOG_TAG, "Pattern Xmitted");
        handler.post(new Runnable() {
            public void run() {
                EventDispatcher.dispatchEvent(thisInstance, "PatternXmitted");
            } // run
        }); // post
    }

    // Übertragung beendet
    @Override
    public void onXmitRepeat() {
        PatternXmitted();
    }

    public int[] patternToIntegerArray(String pattern) {
        // Bei String: Komma-separierte Liste in einem String,
        // oder Semikolon, ggf. mit Blanks
        // Bei List: [100, 200, 300]
        String s = pattern.replace("[", "");
        s = s.replace("]", "");
        s = s.replace(';', ',');
        s = s.replace(" ", "");

        String[] p = s.split(",");

        int[] a = new int[p.length];
        for (int i = 0; i < p.length; i++) {
            try {
                a[i] = Integer.parseInt(p[i]);
            } catch (Exception e) {
                return null;
            }
        }
        return a;
    }

    enum XmitType {
        Single, Repeat
    }

    class ButtonHook {
        Object component; // Zum Vergleichen
        View view;
        XmitType type;
        int[] pattern;
        int[] altPattern;
        int numberOfRepetitions;
        boolean isXmitting = false;

        ButtonHook(Object component, View view, XmitType type, int[] pattern, int[] altPattern,
                int numberOfRepetitions) {
            this.component = component;
            this.view = view;
            this.type = type;
            this.pattern = pattern;
            this.altPattern = altPattern;
            this.numberOfRepetitions = numberOfRepetitions;
        }
    }

    List<ButtonHook> buttons = new ArrayList<ButtonHook>();

    @SimpleFunction(description = "Enables automatic TouchDown / TouchUp handling.")
    public void RegisterButtonForSinglePattern(Object Button, String Pattern) {
        final String functionName = "RegisterButtonForSinglePattern";
        registerButton(functionName, Button, XmitType.Single, 0, Pattern, null);
    }

    @SimpleFunction(description = "Enables automatic TouchDown / TouchUp handling.")
    public void RegisterButtonForRepeatedPattern(Object Button, int Repetitions, String Pattern) {
        final String functionName = "RegisterButtonForRepeatedPattern";
        registerButton(functionName, Button, XmitType.Repeat, Repetitions, Pattern, null);
    }

    @SimpleFunction(description = "Enables automatic TouchDown / TouchUp handling.")
    public void RegisterButtonForRepeatedAltPattern(Object Button, int Repetitions, String Pattern, String AltPattern) {
        final String functionName = "RegisterButtonForRepeatedAltPattern";
        registerButton(functionName, Button, XmitType.Repeat, Repetitions, Pattern, AltPattern);
    }

    void registerButton(String functionName, Object Button, XmitType xType, int Repetitions, String Pattern, String AltPattern) {
        if (!(Button instanceof Button)) {
            form.ErrorOccurred(this, functionName, NOT_BUTTON, NOT_BUTTON_Msg);
            return;
        }

        if (!hasTransmitter) {
            form.ErrorOccurred(this, functionName, HAS_NO_IR_TRANSMITTER, HAS_NO_IR_TRANSMITTER_Msg);
            return;
        }

        int[] pattern = patternToIntegerArray(Pattern);
        if (pattern == null) {
            form.ErrorOccurred(this, functionName, INVALID_PATTERN, INVALID_PATTERN_Msg);
            return;
        }

        int[] secondPattern = null;
        if (AltPattern == null) {
            secondPattern = pattern;
        } else {
            secondPattern = patternToIntegerArray(AltPattern);
            if (secondPattern == null) {
                form.ErrorOccurred(this, functionName, INVALID_REPEAT_PATTERN, INVALID_PATTERN_Msg);
                return;
            }
        }

        for (ButtonHook bh : buttons) { // Wenn bereits eingetragen, dann zuerst löschen
            if (bh.component == Button) {
                buttons.remove(bh);
                break;
            }
        }

        View view = ((Button) Button).getView();
        ButtonHook bh = new ButtonHook(Button, view, xType, pattern, secondPattern, Repetitions);
        buttons.add(bh);
        view.setOnTouchListener(this);
    }

    @Override
    public boolean onTouch(View view, MotionEvent me) {
        final String functionName = "Automated onTouch";
        boolean rtc = false;

        // Welcher Button hat das Ereignis ausgelöst?
        for (ButtonHook bh : buttons) {
            if (bh.view == view) {
                Button button = (Button) bh.component;
                rtc = button.onTouch(view, me);

                if (me.getAction() == MotionEvent.ACTION_DOWN) {
                    if (xmitTask != null) {
                        form.ErrorOccurred(this, functionName, TRANSMITTING_IS_ACTIVE, TRANSMITTING_IS_ACTIVE_Msg);
                        return rtc;
                    }
                    if (bh.type == XmitType.Single) {
                        Log.d(LOG_TAG, "Touch xmit");
                        irManager.transmit(carrierFrequency, bh.pattern);
                        PatternXmitted();
                        TransmitDoneDelayed();
                    } else {
                        Log.d(LOG_TAG, "Touch thread");
                        xmitTask = new XmitTask(this, carrierFrequency, bh.pattern, bh.altPattern,
                                bh.numberOfRepetitions, startDelay, repDelay);
                        bh.isXmitting = true;
                        xmitTask.start();
                    }
                } else if (me.getAction() == MotionEvent.ACTION_UP || me.getAction() == MotionEvent.ACTION_CANCEL) {
                    if (bh.isXmitting) {
                        StopTransmission();
                        bh.isXmitting = false;
                        Log.d(LOG_TAG, "Stop thread");
                    }
                }
                break;
            }
        }

        return rtc;

    }

}