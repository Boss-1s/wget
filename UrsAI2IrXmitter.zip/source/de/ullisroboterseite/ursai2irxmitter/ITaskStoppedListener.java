package de.ullisroboterseite.ursai2irxmitter;

import android.hardware.ConsumerIrManager;

interface ITaskStoppedListener {
    ConsumerIrManager getIrManager();

    void onTaskStopped();

    void onXmitRepeat();
}
